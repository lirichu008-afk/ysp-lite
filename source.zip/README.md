# YSP LIVE Android (API 21)

这是从用户提供的 ysp-live v9.4 源码移植的 Android Studio 工程初始版。

## 技术方案
- minSdk 21 (Android 5.0)
- Chaquopy 13.0 + Python 3.10：在 APK 内运行原始 Python 网关
- ExoPlayer 2.19.1：读取网关生成的 M3U 并播放 HLS
- Android Foreground Service：后台运行本机直播代理
- 监听 0.0.0.0:8767，局域网订阅 `/all.m3u`

## 构建
使用 JDK 17、Android SDK 33、Gradle 7.6.4：
```bash
gradle assembleDebug
```
APK 输出：
`app/build/outputs/apk/debug/app-debug.apk`

也可将工程推送到 GitHub，在 Actions 中手动运行 `Build Android APK`，下载构建产物。

## 当前移植边界
- 原始 `ysp-live.py` 已作为 Python 核心打包，设备状态在应用私有目录首次运行时生成，不复用压缩包内的 `device-state-rs.json`。
- 原项目 Node.js/WASM 伴生兜底引擎暂未集成到 Android 运行时；当前启动参数使用 `--no-engine`。主 Python 设备协议、频道目录、HTTP 代理和缓存代码仍保留。需要单独完成 Node/WASM 引擎的 Android 化，才能宣称所有备用解析路径完全一致。
- 本目录是工程源码，不是已签名/已验证的 APK。必须实际构建并在 Android 5、Android 8+ 真机测试后才能发布。
- 央视频上游接口可能随时变更，4K/8K、回看和设备注册需联网实测。
