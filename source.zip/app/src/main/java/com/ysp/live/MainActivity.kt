package com.ysp.live

import android.content.Intent
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.ExoPlayerFactory
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.ui.PlayerView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

data class LiveChannel(val name: String, val url: String)

class MainActivity : AppCompatActivity() {
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var address: TextView
    private lateinit var list: ListView
    private lateinit var playerView: PlayerView
    private lateinit var player: SimpleExoPlayer
    private val channels = mutableListOf<LiveChannel>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        player = ExoPlayerFactory.newSimpleInstance(this)
        playerView.player = player
        startServer()
        loadChannels()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(8))
        }
        val title = TextView(this).apply {
            text = "YSP LIVE"
            textSize = 24f
            setTextColor(0xFF173B68.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        status = TextView(this).apply { text = "服务正在启动…"; textSize = 14f }
        address = TextView(this).apply {
            text = "订阅地址获取中…"
            textSize = 12f
            setTextIsSelectable(true)
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = Button(this).apply {
            text = "启动服务"
            setOnClickListener { startServer(); loadChannels() }
        }
        val refresh = Button(this).apply {
            text = "刷新频道"
            setOnClickListener { loadChannels() }
        }
        val stop = Button(this).apply {
            text = "停止服务"
            setOnClickListener {
                stopService(Intent(this@MainActivity, YspServerService::class.java))
                status.text = "服务已停止"
            }
        }
        buttons.addView(start, LinearLayout.LayoutParams(0, dp(48), 1f))
        buttons.addView(refresh, LinearLayout.LayoutParams(0, dp(48), 1f))
        buttons.addView(stop, LinearLayout.LayoutParams(0, dp(48), 1f))
        playerView = PlayerView(this).apply {
            useController = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(210)
            )
        }
        list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ -> play(channels[position]) }

        root.addView(title)
        root.addView(status)
        root.addView(address)
        root.addView(buttons)
        root.addView(playerView)
        root.addView(TextView(this).apply {
            text = "频道列表（点击播放）"
            textSize = 16f
            setPadding(0, dp(8), 0, dp(4))
        })
        root.addView(list, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
        address.text = "本机订阅地址：http://${wifiIp()}:${YspServerService.PORT}/all.m3u"
    }

    private fun startServer() {
        val intent = Intent(this, YspServerService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        status.text = "正在启动服务…"
    }

    private fun loadChannels() {
        status.text = "正在读取频道列表…"
        io.execute {
            try {
                val conn = URL("http://127.0.0.1:${YspServerService.PORT}/all.m3u")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 10000
                val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                conn.disconnect()
                val parsed = parseM3u(text)
                runOnUiThread {
                    channels.clear()
                    channels.addAll(parsed)
                    adapter.clear()
                    adapter.addAll(parsed.map { it.name })
                    adapter.notifyDataSetChanged()
                    status.text = "服务可用 · 已加载 ${parsed.size} 个频道"
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "频道加载失败：${e.message}（请稍后刷新）" }
            }
        }
    }

    private fun parseM3u(text: String): List<LiveChannel> {
        val result = mutableListOf<LiveChannel>()
        var pendingName: String? = null
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", true)) {
                pendingName = line.substringAfterLast(',', "未知频道").trim()
            } else if (line.isNotEmpty() && !line.startsWith("#") && pendingName != null) {
                result.add(LiveChannel(pendingName!!, line))
                pendingName = null
            }
        }
        return result
    }

    private fun play(channel: LiveChannel) {
        try {
            player.setMediaItem(MediaItem.fromUri(Uri.parse(channel.url)))
            player.prepare()
            player.playWhenReady = true
            status.text = "正在播放：${channel.name}"
        } catch (e: Exception) {
            status.text = "播放失败：${e.message}"
        }
    }

    private fun wifiIp(): String {
        return try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val raw = wm.connectionInfo.ipAddress
            if (raw == 0) "请连接 Wi-Fi" else Formatter.formatIpAddress(raw)
        } catch (_: Exception) { "请连接 Wi-Fi" }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (::player.isInitialized) player.release()
        io.shutdown()
        super.onDestroy()
    }
}
