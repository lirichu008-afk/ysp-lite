import os
import sys
import threading
import traceback

_core = None
_server = None
_server_thread = None
_lock = threading.RLock()
_last_error = ""

def start_server(port, data_dir, cache_mb=64):
    global _core, _server, _server_thread, _last_error
    with _lock:
        if _server_thread is not None and _server_thread.is_alive():
            return "already_running"
        try:
            import ysp_live_core as core
            _core = core
            original_server = core.ThreadingHTTPServer

            class ManagedHTTPServer(original_server):
                def __init__(self, *args, **kwargs):
                    global _server
                    super().__init__(*args, **kwargs)
                    _server = self

            core.ThreadingHTTPServer = ManagedHTTPServer
            os.makedirs(data_dir, exist_ok=True)
            sys.argv = [
                "ysp-live.py", str(int(port)),
                "--bind", "0.0.0.0",
                "--data-dir", data_dir,
                "--cache-mb", str(int(cache_mb)),
                "--links-per-device", "4",
                "--zap-debounce", "10",
                "--no-engine"
            ]

            def runner():
                global _last_error
                try:
                    core.main()
                except BaseException:
                    _last_error = traceback.format_exc()

            _server_thread = threading.Thread(
                target=runner, name="ysp-live-main", daemon=True
            )
            _server_thread.start()
            return "starting"
        except BaseException:
            _last_error = traceback.format_exc()
            return "error:" + _last_error

def stop_server():
    global _server, _server_thread
    with _lock:
        srv = _server
    if srv is not None:
        try:
            srv.shutdown()
            srv.server_close()
        except Exception:
            pass
    with _lock:
        _server = None
        _server_thread = None
    return "stopped"

def last_error():
    return _last_error
